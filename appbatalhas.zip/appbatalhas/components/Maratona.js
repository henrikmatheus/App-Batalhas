import React from 'react';
import {View,Text,StyleSheet,Button,Image,ScrollView} from 'react-native';
import {useNavigation} from '@react-navigation/native';

function Maratona() {
  const navigation = useNavigation();
  
  return(
    <ScrollView contentContainerStyle={estilo.container}>
    <View style={estilo.container}>
    <Image style={estilo.img} source={require('../assets/maratona.png')} />
    <Text style={estilo.texto}>A Batalha de Maratona foi travada em 490 a.C. entre o Império Persa e as cidades-estado gregas, lideradas por Atenas. O exército persa, liderado por Datis e Artaphernes, desembarcou na planície de Maratona, a cerca de 42 km de Atenas. As forças atenienses, lideradas por Milcíades, conseguiram surpreender os persas e derrotá-los em uma batalha sangrenta. Após a vitória, um soldado ateniense correu cerca de 42 km até Atenas para anunciar a vitória, dando origem à maratona moderna. A batalha de Maratona foi uma importante vitória para os gregos, que conseguiram impedir a invasão persa em seu território e consolidar a importância da democracia e do espírito guerreiro entre as cidades-estado gregas.
    </Text>
    <Image style={estilo.img} source={require('../assets/300.gif')} />
    <Button title="Voltar" onPress={() => navigation.goBack()} />
    </View>
    </ScrollView>
  )
}
export default Maratona;

const estilo = StyleSheet.create({
  container:{
    flex:1,
  },
  texto:{
    fontSize:18,
    textAlign:'justify',
    margin:15,
  },
  img:{
    width: 350,
    height:200, 
    borderRadius: 5,
    resizeMode: 'center'
  }
})