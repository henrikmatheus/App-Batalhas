import React from 'react';
import {View,Text,StyleSheet,ScrollView} from 'react-native';

function Poitiers() {
  return(
    <ScrollView contentContainerStyle={estilo.container}>
  <View style={estilo.container}>
  <Text style={estilo.texto}>A Batalha de Poitiers, também conhecida como a Batalha de Tours, foi travada em 732 d.C. entre o exército franco liderado por Carlos Martel e o exército islâmico liderado por Abderramão, que invadiu a França a partir da península Ibérica. A batalha foi uma das mais decisivas da história europeia, com as forças francas conseguindo derrotar os muçulmanos e impedir a expansão islâmica na Europa ocidental. A vitória de Carlos Martel em Poitiers é vista como um marco na história da cristandade e da Europa, e é considerada uma das batalhas mais importantes da história medieval.
  </Text>
  </View>
  </ScrollView>
  );
}
export default Poitiers;

const estilo = StyleSheet.create({
  container:{
    flex:1,
  },
  texto:{
    fontSize:18,
    textAlign:'justify',
    margin:15,
  },
})