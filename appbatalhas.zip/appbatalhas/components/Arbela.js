import React from 'react';
import {View,Text,StyleSheet,Button,Image,ScrollView,Image1} from 'react-native';
import {useNavigation} from '@react-navigation/native';

function Arbela() {
  const navigation = useNavigation();
  
  return(
    <ScrollView contentContainerStyle={estilo.container}>
    <View style={estilo.container}>
    <Image style={estilo.img} source={require('../assets/arbela.jpg')} />
    <Text style={estilo.texto}>A Batalha de Arbela, também conhecida como Batalha de Gaugamela, foi travada em 331 a.C. entre o Império Persa e o Império Macedônico liderado por Alexandre, o Grande. O exército persa, liderado pelo rei Dario III, tinha uma vantagem numérica significativa, mas Alexandre liderou suas tropas com habilidade e estratégia, quebrando a formação persa e infligindo pesadas baixas ao inimigo. A vitória de Alexandre em Arbela foi decisiva e marcou o fim do Império Persa como uma potência mundial. Alexandre expandiu seus domínios por toda a Ásia e a batalha de Arbela é considerada uma das mais importantes da história, tendo mudado significativamente a geopolítica da época.
    </Text>
    
    <Button title="Voltar" onPress={() => navigation.goBack()} />
    
    </View>
    </ScrollView>
  )
}
export default Arbela;

const estilo = StyleSheet.create({
  container:{
    flex:1,
},
   texto:{
    fontSize:18,
    textAlign:'justify',
    margin:15,
   },

   img:{
    width: 300,
    height: 200, 
    borderRadius: 5,
    resizeMode: 'center'
  }
  
})