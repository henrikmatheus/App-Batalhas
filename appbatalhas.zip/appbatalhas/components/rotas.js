import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';


import Home from './Home';
import Arbela from './Arbela';
import Maratona from './Maratona';
import Poitiers from './Poitiers';

const Tab = createBottomTabNavigator();

function Rotas() {
  return(
    <Tab.Navigator>

     <Tab.Screen
     name="Home"
     component={Home}/>

     <Tab.Screen
     name="Maratona"
     component={Maratona}/>

     <Tab.Screen
     name="Arbela"
     component={Arbela}/>

     <Tab.Screen
     name="Poitiers"
     component={Poitiers}/>

    </Tab.Navigator>
  );
}
export default createBottomTabNavigator();