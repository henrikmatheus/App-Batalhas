import React from 'react';
import {View,Text,StyleSheet,Button} from 'react-native';
import {useNavigation} from '@react-navigation/native';


function Home() {
  const navigation = useNavigation();

  function irMaratona() {
    navigation.navigate('Maratona');
    }
  function irArbela() {
    navigation.navigate('Arbela');
  }
  function irPoitiers() {
    navigation.navigate('Poitiers');
  }

  return(
    <View style={estilo.container}>

    
    <Text style={estilo.titulo}>As maiores batalhas da história</Text>
    <Text style={estilo.introducao}>As guerras sempre foram um fator importante para a humanidade, onde 
    sempre foi decidido qual seria o rumo de um povo, para a grandeza ou para a escravidão. Por isso 
    será destacada algumas das batalhas mais importantes da história.
    </Text>
     <Button title="Maratona" onPress={irMaratona} />
     <Button title="Arbela" onPress={irArbela} />
     <Button title="Poitiers" onPress={irPoitiers} />
    </View>
  )
}
export default Home;

const estilo = StyleSheet.create({
  container:{
    flex:1,
     },
  introducao:{
    fontSize:18,
    textAlign:'justify',
    margin:15,
  },
  titulo:{
    marginTop:30,
    marginBottom:30,
    fontSize:30,
    color:'black',
    fontWeight:'bold',
  },
})