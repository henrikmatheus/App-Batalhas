import Rotas from './components/rotas';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Home from './components/Home';
import Arbela from './components/Arbela';
import Maratona from './components/Maratona';
import Poitiers from './components/Poitiers';

const Tab = createBottomTabNavigator();

function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator>
        <Tab.Screen name="Home" component={Home} />
        <Tab.Screen name="Maratona" component={Maratona} />
        <Tab.Screen name="Arbela" component={Arbela} />
        <Tab.Screen name="Poitiers" component={Poitiers} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

export default App;
